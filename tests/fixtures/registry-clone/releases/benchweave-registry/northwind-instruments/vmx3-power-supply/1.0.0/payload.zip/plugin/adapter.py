# synthetic fixture payload
